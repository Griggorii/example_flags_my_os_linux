#!/bin/bash

####Griggorii@gmail.com mit license notify-send set | less

notify-send "`set:less`"
EOF
notify-send "`set | less`"
EOF
notify-send "`curl -s wttr.in/Moscow?format="%l:+%c+%t+%m+%w\n"`"
EOF
